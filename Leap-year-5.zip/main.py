Y=int(input("Enter the year:"))
if(y%4==0):
    print("leap year")
else:
    print("Not a leap year")